﻿using $safeprojectname$.Context;
using $safeprojectname$.Models;
using $safeprojectname$.Queries.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Queries
{
    public class BasicQueries : IBasicQueries
    {
        private BasicContext _context = null;
        public BasicQueries(BasicContext context)
        {
            _context = context;
        }
        public async Task<BasicModel> GetBasicAsync(int id)
        {
            return await _context.BasicModels.FirstOrDefaultAsync(b => b.Id == id);
        }
        public async Task<IEnumerable<BasicModel>> GetAllBasicAsync()
        {
            return await _context.BasicModels.ToListAsync();
        }
        public async Task<bool> CreateBasicAsync(BasicModel basic)
        {
            int result = 0;
            _context.BasicModels.Add(basic);
            result = await _context.SaveChangesAsync();

            return result >= 0;
        }
        public async Task<bool> DeleteBasicAsync(int id)
        {
            int result = 0;
            var bm = await _context.BasicModels.FirstOrDefaultAsync(b => b.Id == id);

            if (bm != null)
            {
                _context.Remove(bm);
                result = await _context.SaveChangesAsync();

                return result >= 0;
            }
            else
            {
                return false;
            }
        }
        public async Task<bool> UpdateBasicAsync(BasicModel basic)
        {
            int result = 0;
            var bm = await _context.BasicModels.FirstOrDefaultAsync(b => b.Id == basic.Id);

            if (bm != null)
            {
                bm.Name = bm.Description;

                _context.Update(bm);

                result = await _context.SaveChangesAsync();

                return result >= 0;
            }
            else
            {
                return false;
            }
        }
    }
}
