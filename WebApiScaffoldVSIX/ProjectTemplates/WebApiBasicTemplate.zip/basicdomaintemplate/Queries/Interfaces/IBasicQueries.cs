﻿using $safeprojectname$.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Queries.Interfaces
{
    public interface IBasicQueries
    {
        Task<BasicModel> GetBasicAsync(int id);
        Task<IEnumerable<BasicModel>> GetAllBasicAsync();
        Task<bool> CreateBasicAsync(BasicModel basic);
        Task<bool> UpdateBasicAsync(BasicModel basic);
        Task<bool> DeleteBasicAsync(int id);
    }
}
