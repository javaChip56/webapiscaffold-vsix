﻿using $safeprojectname$.Models;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Context
{
    public class BasicContext : DbContext
    {
        public BasicContext(DbContextOptions<BasicContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BasicModel> BasicModels { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // optionsBuilder.UseSqlServer("Server={server},{post};Database={DBName};User Id={username};Password={password};");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BasicModel>(entity =>
            {
                entity.ToTable("BasicModel");

                entity.Property(e => e.Id).HasColumnName("Id");

                entity.Property(e => e.Name)
                    .HasColumnName("Name")
                    .HasMaxLength(100);

                entity.Property(e => e.Description)
                    .HasColumnName("Description")
                    .HasMaxLength(500);
            });
        }
    }
}
