﻿namespace $safeprojectname$.Models
{
    public class BasicModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
