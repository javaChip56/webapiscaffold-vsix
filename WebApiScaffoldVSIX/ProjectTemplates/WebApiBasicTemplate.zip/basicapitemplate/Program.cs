using System;
using System.IO;
using System.Net;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

using Basic.Infrastructure.Logging;

namespace $safeprojectname$
{
    public class Program
    {
        private static string _environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    var config = new ConfigurationBuilder()
                        .SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                        .AddJsonFile("appsettings.{builderContext.HostingEnvironment.EnvironmentName}.json", optional: true)
                        .AddEnvironmentVariables()
                        .Build();

                    webBuilder.UseKestrel(options =>
                    {
                        if (!string.IsNullOrEmpty(_environment) && _environment.ToLower().Equals("development"))
                        {
                            options.Listen(IPAddress.Loopback, 8080);
                        }
                        else
                        {
                            options.Listen(IPAddress.Any, 8080);
                        }
                    });

                    webBuilder.UseSerilog(LoggingService.BuildLogger(config));
                    webBuilder.UseStartup<Startup>();
                });
    }
}
