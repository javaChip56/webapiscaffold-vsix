﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using $safeprojectname$.Filters;
using Basic.Domain.Models;
using Basic.Domain.Queries.Interfaces;

namespace $safeprojectname$.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class BasicController : ControllerBase
    {
        private IBasicQueries _basicQueries;
        public BasicController(IBasicQueries basicQueries)
        {
            _basicQueries = basicQueries;
        }

        [HttpGet]
        [ServiceFilter(typeof(LoggingActionFilter))]
        public async Task<BasicModel> GetBasic(int id)
        {
            return await _basicQueries.GetBasicAsync(id);
        }

        [HttpGet]
        [ServiceFilter(typeof(LoggingActionFilter))]
        public async Task<IEnumerable<BasicModel>> GetAllBasic()
        {
            return await _basicQueries.GetAllBasicAsync();
        }

        [HttpPost]
        [ServiceFilter(typeof(LoggingActionFilter))]
        public async Task<bool> CreateBasic(BasicModel basic)
        {
            return await _basicQueries.CreateBasicAsync(basic);
        }

        [HttpPost]
        [ServiceFilter(typeof(LoggingActionFilter))]
        public async Task<bool> UpdateBasic(BasicModel basic)
        {
            return await _basicQueries.UpdateBasicAsync(basic);
        }

        [HttpPost]
        [ServiceFilter(typeof(LoggingActionFilter))]
        public async Task<bool> DeleteBasic(int id)
        {
            return await _basicQueries.DeleteBasicAsync(id);
        }
    }
}