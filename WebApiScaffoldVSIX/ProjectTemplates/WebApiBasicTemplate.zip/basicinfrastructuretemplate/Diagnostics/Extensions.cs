﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Diagnostics
{
    public static partial class WebHostBuilderExtension
    {
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path)
        {
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path);
        }
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path, HealthCheckOptions options)
        { 
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path, options);
        }
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path, int port) 
        { 
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path, port);
        }
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path, int port, HealthCheckOptions options)
        { 
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path, port, options);
        }
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path, string port)
        { 
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path, port);
        }
        public static IApplicationBuilder UseHealthChecks(this IApplicationBuilder app, PathString path, string port, HealthCheckOptions options)
        { 
            return HealthCheckApplicationBuilderExtensions.UseHealthChecks(app, path, port, options);
        }
        //public static IHealthChecksBuilder AddHealthChecks(this IServiceCollection services)
        //{ 
        //    return HealthCheckServiceCollectionExtensions.AddHealthChecks(services);
        //}
    }
}
