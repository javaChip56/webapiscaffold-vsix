﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Diagnostics
{
    public class HealthCheckOptions 
        : Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions
    {

    }
}
