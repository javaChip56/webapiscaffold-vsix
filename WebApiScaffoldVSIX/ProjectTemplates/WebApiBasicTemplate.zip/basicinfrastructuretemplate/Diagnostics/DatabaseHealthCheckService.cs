﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace $safeprojectname$.Diagnostics
{
    public class DatabaseHealthCheckService : IHealthCheck
    {
        private string _connectionString = string.Empty;
        public DatabaseHealthCheckService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = new CancellationToken())
        {
            string dbName = string.Empty;

            using (var conn = new SqlConnection(_connectionString))
            {
                dbName = conn.Database;

                try
                {
                    await conn.OpenAsync(cancellationToken);
                }
                catch (SqlException ex)
                {
                    return await Task.FromResult(new HealthCheckResult(status: context.Registration.FailureStatus, exception: ex));
                }
            }

            return await Task.FromResult(HealthCheckResult.Healthy(dbName + " is Healthy."));
        }
    }
}
