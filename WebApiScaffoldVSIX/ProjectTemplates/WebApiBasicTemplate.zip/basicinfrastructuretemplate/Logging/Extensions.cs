﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Serilog;
using Serilog.Extensions.Logging;

namespace $safeprojectname$.Logging
{
    public static class WebHostBuilderExtension
    {
        public static IWebHostBuilder UseSerilog(this IWebHostBuilder builder, ILogger logger = null, bool dispose = false, LoggerProviderCollection providers = null)
        {
            return SerilogWebHostBuilderExtensions.UseSerilog(
                builder, logger, dispose , providers);
        }
        public static IWebHostBuilder UserSerilog(this IWebHostBuilder builder, Action<WebHostBuilderContext, LoggerConfiguration> configureLogger, bool preserveStaticLogger = false, bool writeToProviders = false)
        {
            return SerilogWebHostBuilderExtensions.UseSerilog(
                builder, configureLogger, preserveStaticLogger, writeToProviders);
        }
    }
}
